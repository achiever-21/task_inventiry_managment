import React, { useState, useEffect } from 'react';
import axios from 'axios';

const ProductManagement = () => {
    const [products, setProducts] = useState([]);
    const [categories, setCategories] = useState([]);
    const [formData, setFormData] = useState({
      id: null,
      name: '',
      category: '',
      stock: 0,
      reorderPoint: 0,
    });
    const [isEditing, setIsEditing] = useState(false);
  
    // Fetch products and categories on component load
    useEffect(() => {
      fetchProducts();
      fetchCategories();
    }, []);
  
    const fetchProducts = async () => {
      try {
        const response = await axios.get('/api/products');
        setProducts(response.data);
      } catch (error) {
        console.error('Error fetching products:', error);
      }
    };
  
    const fetchCategories = async () => {
      try {
        const response = await axios.get('/api/categories');
        setCategories(response.data);
      } catch (error) {
        console.error('Error fetching categories:', error);
      }
    };
  
    const handleInputChange = (e) => {
      const { name, value } = e.target;
      setFormData({ ...formData, [name]: value });
    };
  
    const handleSubmit = async (e) => {
      e.preventDefault();
      try {
        if (isEditing) {
          // Update product
          await axios.put(`/api/products/${formData.id}`, formData);
          alert('Product updated successfully!');
        } else {
          // Add new product
          await axios.post('/api/products', formData);
          alert('Product added successfully!');
        }
        fetchProducts();
        resetForm();
      } catch (error) {
        console.error('Error saving product:', error);
      }
    };
  
    const handleEdit = (product) => {
      setFormData(product);
      setIsEditing(true);
    };
  
    const handleDelete = async (id) => {
      if (window.confirm('Are you sure you want to delete this product?')) {
        try {
          await axios.delete(`/api/products/${id}`);
          alert('Product deleted successfully!');
          fetchProducts();
        } catch (error) {
          console.error('Error deleting product:', error);
        }
      }
    };
  
    const resetForm = () => {
      setFormData({
        id: null,
        name: '',
        category: '',
        stock: 0,
        reorderPoint: 0,
      });
      setIsEditing(false);
    };
  
  return (
    <div>
      <h2>Product Management</h2>

     
      <form onSubmit={handleSubmit}>
        <div>
          <label>Product Name:</label>
          <input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleInputChange}
            required
          />
        </div>
        <div>
          <label>Category:</label>
          <select
            name="category"
            value={formData.category}
            onChange={handleInputChange}
            required
          >
            <option value="">Select Category</option>
            {categories.map((category) => (
              <option key={category.id} value={category.name}>
                {category.name}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label>Stock:</label>
          <input
            type="number"
            name="stock"
            value={formData.stock}
            onChange={handleInputChange}
            required
          />
        </div>
        <div>
          <label>Reorder Point:</label>
          <input
            type="number"
            name="reorderPoint"
            value={formData.reorderPoint}
            onChange={handleInputChange}
            required
          />
        </div>
        <button type="submit">{isEditing ? 'Update Product' : 'Add Product'}</button>
        {isEditing && <button onClick={resetForm}>Cancel</button>}
      </form>

      {/* Product List */}
      <h3>Product List</h3>
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Category</th>
            <th>Stock</th>
            <th>Reorder Point</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {products.map((product) => (
            <tr key={product.id}>
              <td>{product.name}</td>
              <td>{product.category}</td>
              <td>{product.stock}</td>
              <td>{product.reorderPoint}</td>
              <td>
                <button onClick={() => handleEdit(product)}>Edit</button>
                <button onClick={() => handleDelete(product.id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ProductManagement;
