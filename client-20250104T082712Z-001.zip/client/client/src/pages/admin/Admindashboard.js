import React from 'react';
import { Link } from 'react-router-dom';

const AdminDashboard = () => {
  return (
    <div>
      <h1>Admin Dashboard</h1>
      <ul>
        <li><Link to="/admin/users">Manage Users</Link></li>
        <li><Link to="/admin/products">Manage Products</Link></li>
        <li><Link to="/admin/suppliers">Manage Suppliers</Link></li>
        <li><Link to="/admin/stock">Manage Stock</Link></li>
        <li><Link to="/admin/reports">View Reports</Link></li>
      </ul>
    </div>
  );
};

export default AdminDashboard;
