import React, { useState } from "react";
import "./Login.css"; 
const Login = () => {
  const [formData, setFormData] = useState({
    username: "",
    password: "",
    role: "user",
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Form Data Submitted:", formData);
    
  };

  return (
    <div className="login-container">
      <h2>Login</h2>
      <form onSubmit={handleSubmit}>
        <label htmlFor="username">Username</label>
        <input
          type="text"
          id="username"
          name="username"
          required
          placeholder="Enter your username"
          value={formData.username}
          onChange={handleInputChange}
        />

        <label htmlFor="password">Password</label>
        <input
          type="password"
          id="password"
          name="password"
          required
          placeholder="Enter your password"
          value={formData.password}
          onChange={handleInputChange}
        />

        <label htmlFor="role" className="login-type">
          Login As
        </label>
        <select
          id="role"
          name="role"
          required
          value={formData.role}
          onChange={handleInputChange}
        >
          <option value="user">User</option>
          <option value="manager">Manager</option>
          <option value="admin">Admin</option>
        </select>

        <button type="submit">Login</button>
      </form>
    </div>
  );
};

export default Login;