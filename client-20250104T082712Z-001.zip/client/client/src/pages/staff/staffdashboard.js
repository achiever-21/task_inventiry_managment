import React from 'react';
import { Link } from 'react-router-dom';

const StaffDashboard = () => {
  return (
    <div>
      <h1>Staff Dashboard</h1>
      <ul>
        <li><Link to="/staff/products">View Products</Link></li>
        <li><Link to="/staff/stock">Perform Stock Transactions</Link></li>
      </ul>
    </div>
  );
};

export default StaffDashboard;
