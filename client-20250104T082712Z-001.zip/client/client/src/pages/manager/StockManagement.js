import React, { useState, useEffect } from 'react';
import axios from 'axios';

const StockManagement = () => {
  const [stock, setStock] = useState([]);

  useEffect(() => {
    axios.get('/api/stock').then((response) => {
      setStock(response.data);
    });
  }, []);

  return (
    <div>
      <h2>Stock Management</h2>
      <table>
        <thead>
          <tr>
            <th>Product</th>
            <th>Quantity</th>
            <th>Last Updated</th>
          </tr>
        </thead>
        <tbody>
          {stock.map((item) => (
            <tr key={item.id}>
              <td>{item.productName}</td>
              <td>{item.quantity}</td>
              <td>{new Date(item.updatedAt).toLocaleString()}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default StockManagement;
