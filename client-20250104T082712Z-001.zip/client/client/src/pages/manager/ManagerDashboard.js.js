import React from 'react';
import { Link } from 'react-router-dom';

const ManagerDashboard = () => {
  return (
    <div>
      <h1>Manager Dashboard</h1>
      <ul>
        <li><Link to="/manager/products">Manage Products</Link></li>
        <li><Link to="/manager/suppliers">Manage Suppliers</Link></li>
        <li><Link to="/manager/stock">Manage Stock</Link></li>
      </ul>
    </div>
  );
};

export default ManagerDashboard;
